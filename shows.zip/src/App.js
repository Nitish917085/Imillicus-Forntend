import './App.css';
import Tables from './pages/Tables';

function App() {
  return (
    <div className="App">
      <Tables/>
    </div>
  );
}

export default App;
